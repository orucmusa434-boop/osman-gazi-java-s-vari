package net.osmangazi;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** El topçusu: sağ tık ile envanterdeki gülleyi atar. */
public class HandCannonItem extends Item {
    public HandCannonItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack gun = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;
        ItemStack ammo = findAmmo(player);
        if (ammo.isEmpty() && !creative) return InteractionResultHolder.fail(gun);
        if (!level.isClientSide) {
            CannonballEntity b = new CannonballEntity(level, player);
            b.setDamage(8.0F);
            b.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 2.2F, 1.0F);
            level.addFreshEntity(b);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8F, 1.5F);
            if (!creative) {
                ammo.shrink(1);
                gun.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
        }
        player.getCooldowns().addCooldown(this, 30);
        player.awardStat(Stats.ITEM_USED.get(this));
        return InteractionResultHolder.sidedSuccess(gun, level.isClientSide());
    }

    private static ItemStack findAmmo(Player p) {
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.is(ModItems.GULLE.get())) return s;
        }
        return ItemStack.EMPTY;
    }
}
