package net.osmangazi;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.osmangazi.client.GuideClient;

/** Osman Gazi Rehberi: sağ tıklayınca evcilleştirme bilgilerini gösteren kitap. */
public class GuideBookItem extends Item {
    public GuideBookItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> GuideClient.open());
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
