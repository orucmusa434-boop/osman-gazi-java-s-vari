package net.osmangazi.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Rehber kitabının metni. Dil ayarından bağımsız olarak her zaman Türkçe gösterilir. */
public class GuideClient {
    private static final String[] PAGES = {
        "§lOsman Gazi Rehberi§r\n\nBirimi evcilleştirmek için ilgili eşyayla birime sağ tıkla.\n\nEşya her denemede harcanır. Şans tutmazsa tekrar dene.\n\nEvcil birime boş elle sağ tıklarsan oturur ya da seni takip eder.",
        "§lAlp§r\n\nAlp: elmas\nOkçu: altın külçe\nÇekiçli: meşe kapı\nKalkanlı: kömür\nKazmacı: Alp Kazması\nTopçu: barut\nSüvari: altın havuç\nAlp Atı: elma",
        "§lMoğol§r\n\nAsker: zümrüt\nOkçu: altın külçe\nÇekiçli: huş kapı\nKalkanlı: lacivert taşı\nKazmacı: Moğol Kazması\nTopçu: çakmaktaşı\nSüvari: şeker\nMoğol Atı: buğday",
        "§lBarbar§r\n\nBarbar: demir külçe\nOkçu: bakır külçe\nÇekiçli: akasya kapı\nKalkanlı: kızıltaş tozu\nKazmacı: Barbar Kazması\nTopçu: alev tozu\nSüvari: deri\nBarbar Atı: havuç",
        "§lKomutanlar ve Krallar§r\n\nKonur Alp, Konur Moğol, Konur Barbar: altın elma ya da kendi kazmaları (%15)\n\nOsman Gazi: elmas blok (%50)\nNayman Han: zümrüt blok (%40)\nAlpago: demir blok (%40)",
        "§lAtlar§r\n\nAtı evcilleştirdikten sonra boş elle sağ tıkla ve bin. Eyer gerekmez.\n\nAlp Atı: elma\nMoğol Atı: buğday\nBarbar Atı: havuç\n\nŞans: %50",
        "§lEl Topçusu§r\n\nSağ tıkla ateşle. Envanterinde gülle olmalı.\n\nGülle: 1 demir külçe + 1 barut = 2 gülle.\n\nEl Topçusu: üstte 3 demir külçe, sağ sütunda aşağı doğru çakmaktaşı ve çubuk.",
        "§lİpuçları§r\n\nKonur'lar ve krallar yakındaki dost askerlere güç, direnç ve hız verir.\n\nKalkanlı birimler öndeki vuruşları engeller.\n\nAlp, Moğol ve Barbar birbirine düşmandır. Barbarlar sana da saldırır."
    };

    public static void open() {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "Osman Gazi Rehberi");
        tag.putString("author", "Osman Gazi");
        ListTag pages = new ListTag();
        for (String p : PAGES) pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(p))));
        tag.put("pages", pages);
        Minecraft.getInstance().setScreen(new BookViewScreen(new BookViewScreen.WrittenBookAccess(book)));
    }
}
