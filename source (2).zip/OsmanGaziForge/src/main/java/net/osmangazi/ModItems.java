package net.osmangazi;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, OsmanGaziMod.MODID);
    public static final List<RegistryObject<Item>> ALL = new ArrayList<>();
    public static final List<RegistryObject<Item>> EGGS = new ArrayList<>();
    public static final RegistryObject<Item> GULLE;

    private static RegistryObject<Item> reg(String name, Supplier<Item> s) {
        RegistryObject<Item> o = ITEMS.register(name, s); ALL.add(o); return o;
    }
    private static void regEgg(String id, int c1, int c2) {
        EGGS.add(ITEMS.register(id + "_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.object(id), c1, c2, new Item.Properties())));
    }

    private static void regHorseEgg(String id, int c1, int c2) {
        EGGS.add(ITEMS.register(id + "_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.horseObject(id), c1, c2, new Item.Properties())));
    }

    static {
        reg("alp_baltasi", () -> new AxeItem(Tiers.IRON, 4.0F, -3.0F, new Item.Properties().durability(900)));
        reg("alp_cekici", () -> new SwordItem(Tiers.IRON, 6, -3.0F, new Item.Properties().durability(1000)));
        reg("alp_kazmasi", () -> new PickaxeItem(Tiers.DIAMOND, 1, -2.8F, new Item.Properties().durability(900)));
        reg("alp_kilici", () -> new SwordItem(Tiers.IRON, 5, -2.4F, new Item.Properties().durability(1000)));
        reg("alp_mizragi", () -> new SwordItem(Tiers.IRON, 5, -2.8F, new Item.Properties().durability(900)));
        reg("alp_oku", () -> new OsmanArrowItem(new Item.Properties()));
        reg("alp_yayi", () -> new BowItem(new Item.Properties().durability(700)));
        reg("alpago_baltasi", () -> new AxeItem(Tiers.IRON, 9.0F, -3.0F, new Item.Properties().durability(1500)));
        reg("barbar_baltasi", () -> new AxeItem(Tiers.IRON, 5.0F, -3.0F, new Item.Properties().durability(900)));
        reg("barbar_cekici", () -> new SwordItem(Tiers.IRON, 6, -3.0F, new Item.Properties().durability(1000)));
        reg("barbar_kazmasi", () -> new PickaxeItem(Tiers.IRON, 2, -2.8F, new Item.Properties().durability(900)));
        reg("barbar_mizragi", () -> new SwordItem(Tiers.IRON, 5, -2.8F, new Item.Properties().durability(900)));
        reg("barbar_oku", () -> new OsmanArrowItem(new Item.Properties()));
        reg("barbar_yayi", () -> new BowItem(new Item.Properties().durability(700)));
        reg("kayi_bayragi", () -> new Item(new Item.Properties().stacksTo(16)));
        reg("kayi_kilici", () -> new SwordItem(Tiers.IRON, 3, -2.4F, new Item.Properties().durability(600)));
        reg("lahmacun", () -> new LahmacunItem(new Item.Properties().food(new FoodProperties.Builder().nutrition(16).saturationMod(0.6F).alwaysEat().build())));
        reg("mongol_cekici", () -> new SwordItem(Tiers.IRON, 6, -3.0F, new Item.Properties().durability(850)));
        reg("mongol_kazmasi", () -> new PickaxeItem(Tiers.IRON, 2, -2.8F, new Item.Properties().durability(900)));
        reg("mongol_kilici", () -> new SwordItem(Tiers.IRON, 4, -2.4F, new Item.Properties().durability(700)));
        reg("mongol_mizragi", () -> new SwordItem(Tiers.IRON, 4, -2.8F, new Item.Properties().durability(750)));
        reg("mongol_oku", () -> new OsmanArrowItem(new Item.Properties()));
        reg("mongol_yayi", () -> new BowItem(new Item.Properties().durability(550)));
        reg("nayman_kilici", () -> new SwordItem(Tiers.IRON, 9, -2.4F, new Item.Properties().durability(2200)));
        reg("osman_kilici", () -> new SwordItem(Tiers.IRON, 6, -2.4F, new Item.Properties().durability(1800)));
        GULLE = reg("gulle", () -> new Item(new Item.Properties()));
        reg("el_topu", () -> new HandCannonItem(new Item.Properties().durability(300)));
        reg("rehber_kitabi", () -> new GuideBookItem(new Item.Properties().stacksTo(1)));
        regEgg("alp", 0xA02828, 0xE6C850);
        regEgg("alp_okcu", 0x566840, 0xA02828);
        regEgg("alp_cekicli", 0xA02828, 0x969CA8);
        regEgg("alp_kalkanli", 0xA02828, 0x969CA8);
        regEgg("alp_kazmaci", 0xA02828, 0xF0BE28);
        regEgg("konur_alp", 0xA02828, 0xFFD23C);
        regEgg("osman_gazi", 0x1E7341, 0xEBC846);
        regEgg("mongol_asker", 0x2D3C64, 0xAA2828);
        regEgg("mongol_okcu", 0x3C5C62, 0xAA2828);
        regEgg("mongol_cekicli", 0x2D3C64, 0x464852);
        regEgg("mongol_kalkanli", 0x2D3C64, 0x34261A);
        regEgg("mongol_kazmaci", 0x2D3C64, 0xE07024);
        regEgg("konur_mongol", 0x2D3C64, 0xFF9A28);
        regEgg("nayman", 0x2D193C, 0xD7AA28);
        regEgg("barbar", 0x46542E, 0xB8A078);
        regEgg("barbar_okcu", 0x5C4A30, 0x46542E);
        regEgg("barbar_cekicli", 0x46542E, 0x7A7A80);
        regEgg("barbar_kalkanli", 0x46542E, 0x8A5A34);
        regEgg("barbar_kazmaci", 0x46542E, 0xB09660);
        regEgg("konur_barbar", 0x46542E, 0xD23C3C);
        regEgg("alpago", 0x23231F, 0xD7AA28);
        regEgg("alp_topcu", 0xA02828, 0x2B2B2B);
        regEgg("mongol_topcu", 0x2D3C64, 0x2B2B2B);
        regEgg("barbar_topcu", 0x46542E, 0x2B2B2B);
        regEgg("alp_suvari", 0xA02828, 0xE0E0E0);
        regEgg("mongol_suvari", 0x2D3C64, 0xE0E0E0);
        regEgg("barbar_suvari", 0x46542E, 0xE0E0E0);
        regHorseEgg("alp_ati", 0xF0F0F0, 0xA02828);
        regHorseEgg("mongol_ati", 0x8B4A2B, 0x2D3C64);
        regHorseEgg("barbar_ati", 0x1E1E1E, 0x46542E);
    }
}
