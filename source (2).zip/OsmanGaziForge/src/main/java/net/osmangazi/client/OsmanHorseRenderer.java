package net.osmangazi.client;

import net.minecraft.client.model.HorseModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.AbstractHorseRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.osmangazi.OsmanHorse;

public class OsmanHorseRenderer extends AbstractHorseRenderer<OsmanHorse, HorseModel<OsmanHorse>> {
    public OsmanHorseRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HorseModel<>(ctx.bakeLayer(ModelLayers.HORSE)), 1.1F);
    }

    @Override
    public ResourceLocation getTextureLocation(OsmanHorse horse) { return horse.texture(); }
}
