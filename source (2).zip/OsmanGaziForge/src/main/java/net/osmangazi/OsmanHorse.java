package net.osmangazi;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.registries.ForgeRegistries;

/** Alp / Moğol / Barbar atı. Eyer gerekmeden binilir. */
public class OsmanHorse extends AbstractHorse {
    public record HorseDef(String id, UnitDef.Faction faction, String texture, String tameItem) {}

    public static final List<HorseDef> ALL = List.of(
        new HorseDef("alp_ati", UnitDef.Faction.ALP, "textures/entity/horse/horse_white.png", "minecraft:apple"),
        new HorseDef("mongol_ati", UnitDef.Faction.MONGOL, "textures/entity/horse/horse_chestnut.png", "minecraft:wheat"),
        new HorseDef("barbar_ati", UnitDef.Faction.BARBAR, "textures/entity/horse/horse_black.png", "minecraft:carrot"));

    private final HorseDef hdef;

    public OsmanHorse(EntityType<? extends AbstractHorse> type, Level level, HorseDef hdef) {
        super(type, level);
        this.hdef = hdef;
    }

    public HorseDef hdef() { return hdef; }

    public ResourceLocation texture() { return new ResourceLocation("minecraft", hdef.texture()); }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractHorse.createBaseHorseAttributes()
            .add(Attributes.MAX_HEALTH, 40.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    // Üzerinde biri yokken dolaşır; süvari bindiğinde yönlendirmeyi süvari yapar.
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.2D) {
            @Override public boolean canUse() { return getFirstPassenger() == null && super.canUse(); }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D) {
            @Override public boolean canUse() { return getFirstPassenger() == null && super.canUse(); }
        });
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    // Eyer gerekmez: her zaman eyerli sayılır.
    @Override
    public boolean isSaddled() { return true; }

    // Sadece oyuncu atı yönlendirir; süvariyi atın kendi yapay zekâsı taşır.
    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return getFirstPassenger() instanceof Player p ? p : null;
    }

    private boolean isTameItem(ItemStack s) {
        if (s.isEmpty()) return false;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        return k != null && k.toString().equals(hdef.tameItem());
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isTamed()) {
            if (isTameItem(stack)) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    if (random.nextFloat() < 0.5F) {
                        setTamed(true);
                        setOwnerUUID(player.getUUID());
                        level().broadcastEntityEvent(this, (byte) 7);
                    } else level().broadcastEntityEvent(this, (byte) 6);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }
        if (hand == InteractionHand.MAIN_HAND && stack.isEmpty() && !isVehicle() && !isBaby()
            && player.getUUID().equals(getOwnerUUID()) && !player.isSecondaryUseActive()) {
            if (!level().isClientSide) doPlayerRide(player);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override public boolean isFood(ItemStack s) { return false; }
    @Override protected boolean canParent() { return false; }
    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel l, AgeableMob o) { return null; }
    @Override public boolean removeWhenFarAway(double d) { return !isTamed() && !isVehicle(); }
}
