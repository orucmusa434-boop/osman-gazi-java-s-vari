package net.osmangazi;

import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

/** Tüm Alp / Moğol / Barbar birimleri için tek, parametreli varlık sınıfı. */
public class OsmanUnit extends TamableAnimal implements RangedAttackMob {
    private final UnitDef def;
    @Nullable private final ServerBossEvent bossEvent;

    public OsmanUnit(EntityType<? extends TamableAnimal> type, Level level, UnitDef def) {
        super(type, level);
        this.def = def;
        this.bossEvent = def.role() == UnitDef.Role.KING
            ? new ServerBossEvent(Component.translatable("entity.osmangazi." + def.id()), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.PROGRESS)
            : null;
        this.xpReward = def.role() == UnitDef.Role.KING ? 200 : def.role() == UnitDef.Role.COMMANDER ? 100 : 10;
        if (getNavigation() instanceof GroundPathNavigation g) g.setCanOpenDoors(true);
        // Mob() kurucusu registerGoals()'u def henüz atanmadan çağırır; hedefleri burada def hazırken kuruyoruz.
        registerGoals();
    }

    public UnitDef def() { return def; }

    // Ata binmişken yürüyüş ve hareket atın yönlendirmesiyle yapılır.
    @Override
    public PathNavigation getNavigation() {
        if (isPassenger() && getVehicle() instanceof Mob m) return m.getNavigation();
        return super.getNavigation();
    }

    @Override
    public MoveControl getMoveControl() {
        if (isPassenger() && getVehicle() instanceof Mob m) return m.getMoveControl();
        return super.getMoveControl();
    }

    /** Evcil süvari, ata binmişken sahibini takip eder. */
    private class MountedFollowOwnerGoal extends Goal {
        MountedFollowOwnerGoal() { setFlags(EnumSet.of(Goal.Flag.MOVE)); }

        @Override public boolean canUse() {
            LivingEntity o = getOwner();
            return isTame() && isPassenger() && getVehicle() instanceof Mob && !isOrderedToSit()
                && o != null && !o.isSpectator() && distanceToSqr(o) > 36.0D;
        }

        @Override public boolean canContinueToUse() {
            LivingEntity o = getOwner();
            return canUse() && o != null && distanceToSqr(o) > 9.0D;
        }

        @Override public void tick() {
            LivingEntity o = getOwner();
            if (o != null) getNavigation().moveTo(o, 1.2D);
        }
    }

    public static AttributeSupplier.Builder createAttributes(UnitDef d) {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, d.health())
            .add(Attributes.ATTACK_DAMAGE, d.attack())
            .add(Attributes.MOVEMENT_SPEED, d.speed())
            .add(Attributes.KNOCKBACK_RESISTANCE, d.role() == UnitDef.Role.KING ? 0.8D : d.role() == UnitDef.Role.COMMANDER ? 0.6D : 0.2D)
            .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    // ---------- Yapay zeka ----------
    @Override
    protected void registerGoals() {
        if (def == null) return; // üst sınıf kurucusundan gelen erken çağrı; asıl kurulum OsmanUnit kurucusunda
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        if (def.role() == UnitDef.Role.ARCHER) this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0D, 20, 16.0F));
        else if (def.role() == UnitDef.Role.ARTILLERY) this.goalSelector.addGoal(2, new RangedAttackGoal(this, 0.9D, 70, 24.0F));
        else this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(3, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(5, new MountedFollowOwnerGoal());
        this.goalSelector.addGoal(6, new FollowOwnerGoal(this, 1.1D, 10.0F, 3.0F, false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, this::isEnemy));
    }

    /** Kimlere saldırır? */
    private boolean isEnemy(LivingEntity e) {
        if (e == this || e == getOwner()) return false;
        if (e instanceof OsmanUnit u) {
            if (isTame() && u.isTame()) return false;
            if (isTame()) return u.def.faction() == UnitDef.Faction.BARBAR;
            if (u.isTame()) return def.faction() == UnitDef.Faction.BARBAR;
            return u.def.faction() != def.faction();
        }
        if (e instanceof Player) return !isTame() && def.faction() == UnitDef.Faction.BARBAR;
        if (e instanceof Enemy) return isTame() || def.faction() != UnitDef.Faction.BARBAR;
        return false;
    }

    public boolean isAlly(OsmanUnit u) {
        if (isTame() != u.isTame()) return false;
        return isTame() || u.def.faction() == def.faction();
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        if (target instanceof OsmanUnit u && u.isTame() && owner.equals(u.getOwner())) return false;
        return super.wantsToAttack(target, owner);
    }

    // ---------- Ekipman ----------
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance diff, MobSpawnType reason, @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData r = super.finalizeSpawn(level, diff, reason, data, tag);
        ResourceLocation w = new ResourceLocation(def.weapon());
        if (ForgeRegistries.ITEMS.containsKey(w)) setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ForgeRegistries.ITEMS.getValue(w)));
        if (def.shield()) setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
        if (def.role() == UnitDef.Role.CAVALRY && !isPassenger()) {
            OsmanHorse horse = ModEntities.horseType(def.faction()).create(level.getLevel());
            if (horse != null) {
                horse.moveTo(getX(), getY(), getZ(), getYRot(), 0.0F);
                horse.finalizeSpawn(level, diff, MobSpawnType.JOCKEY, null, null);
                startRiding(horse);
                level.addFreshEntity(horse);
            }
        }
        return r;
    }

    @Override public boolean isBaby() { return false; }
    @Override public boolean isFood(ItemStack s) { return false; }
    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel l, AgeableMob o) { return null; }

    // ---------- Menzilli saldırı ----------
    @Override
    public void performRangedAttack(LivingEntity target, float power) {
        if (def.role() == UnitDef.Role.ARTILLERY) {
            CannonballEntity ball = new CannonballEntity(level(), this);
            ball.setDamage(6.0F + (float) def.attack());
            double bx = target.getX() - getX(), bz = target.getZ() - getZ();
            double by = target.getY(0.5D) - ball.getY();
            double bh = Math.sqrt(bx * bx + bz * bz);
            ball.shoot(bx, by + bh * 0.12D, bz, 1.6F, 3.0F);
            playSound(SoundEvents.GENERIC_EXPLODE, 0.8F, 1.5F);
            level().addFreshEntity(ball);
            return;
        }
        AbstractArrow arrow = ProjectileUtil.getMobArrow(this, new ItemStack(Items.ARROW), power);
        double dx = target.getX() - getX(), dz = target.getZ() - getZ();
        double dy = target.getY(0.3333333333333333D) - arrow.getY();
        double h = Math.sqrt(dx * dx + dz * dz);
        arrow.setBaseDamage(2.0D + def.attack() * 0.4D);
        arrow.shoot(dx, dy + h * 0.2F, dz, 1.6F, (float) (14 - level().getDifficulty().getId() * 4));
        playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.0F / (getRandom().nextFloat() * 0.4F + 0.8F));
        level().addFreshEntity(arrow);
    }

    // ---------- Kalkan ----------
    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (def.shield() && !level().isClientSide && src.getDirectEntity() != null && !src.is(DamageTypeTags.BYPASSES_SHIELD)) {
            Vec3 from = src.getSourcePosition();
            if (from != null) {
                Vec3 to = from.vectorTo(position()).normalize();
                to = new Vec3(to.x, 0.0D, to.z);
                if (to.dot(getViewVector(1.0F)) < 0.0D && random.nextFloat() < 0.6F) {
                    level().playSound(null, blockPosition(), SoundEvents.SHIELD_BLOCK, getSoundSource(), 1.0F, 0.8F + random.nextFloat() * 0.4F);
                    return false;
                }
            }
        }
        return super.hurt(src, amount);
    }

    // ---------- Evcilleştirme / oturma ----------
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isTame()) {
            if (def.isTameItem(stack)) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    if (random.nextFloat() < def.tameChance()) {
                        tame(player);
                        navigation.stop();
                        setTarget(null);
                        setOrderedToSit(false);
                        level().broadcastEntityEvent(this, (byte) 7);
                    } else level().broadcastEntityEvent(this, (byte) 6);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }
        if (isOwnedBy(player) && hand == InteractionHand.MAIN_HAND && stack.isEmpty()) {
            if (!level().isClientSide) {
                setOrderedToSit(!isOrderedToSit());
                jumping = false; navigation.stop(); setTarget(null);
                player.displayClientMessage(Component.translatable(isOrderedToSit() ? "message.osmangazi.sit" : "message.osmangazi.follow"), true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    // ---------- Komutan aurasi + boss bar ----------
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (bossEvent != null) bossEvent.setProgress(getHealth() / getMaxHealth());
        if ((def.role() == UnitDef.Role.COMMANDER || def.role() == UnitDef.Role.KING) && tickCount % 100 == 0) {
            List<OsmanUnit> list = level().getEntitiesOfClass(OsmanUnit.class, getBoundingBox().inflate(18.0D), u -> u != this && isAlly(u));
            for (OsmanUnit u : list) {
                u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 0, true, false));
                u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0, true, false));
                u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0, true, false));
            }
        }
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); if (bossEvent != null) bossEvent.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); if (bossEvent != null) bossEvent.removePlayer(p); }
    @Override public void setCustomName(@Nullable Component n) { super.setCustomName(n); if (bossEvent != null) bossEvent.setName(getDisplayName()); }

    @Override public boolean removeWhenFarAway(double d) { return !isTame() && def.role() != UnitDef.Role.KING; }
}
