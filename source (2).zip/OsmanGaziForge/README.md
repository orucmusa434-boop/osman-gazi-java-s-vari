# Osman Gazi Modu v2.0.0 - Forge 1.20.1 (47.3.0)

Bedrock'taki Osman Gazi modunun Java (Forge 1.20.1) sürümü. **1. aşama: çekirdek içerik.**

## Bu aşamada olanlar
- **21 birim** (hepsi evcilleştirilebilir, doğal doğar, spawn yumurtası var):
  - Alp: Alp, Okçu, Çekiççi, Kalkanlı, Kazmacı, Konur Alp, Osman Gazi (kral)
  - Moğol: Moğol Askeri, Okçu, Çekiççi, Kalkanlı, Kazmacı, Konur Moğol, Nayman (kral)
  - Barbar: Barbar, Okçu, Çekiççi, Kalkanlı, Kazmacı, Konur Barbar, Alpago (kral)
- Düşmanlık: Alp / Moğol / Barbar birbirine düşman, Barbarlar oyuncuya da saldırır. Evcil birimler seni ve diğer evcil birimleri korur.
- Kalkanlı birimler önden gelen vuruşların çoğunu bloklar. Okçular ok atar. Krallar boss bar'lı.
- Konur komutanlar ve krallar yakındaki dost askerlere güç, direnç ve hız aurası verir.
- Evcilleştirme: ilgili eşya ile sağ tık (Alp: elmas, Barbar: demir külçe, kazmacılar: kendi kazması...). Evcilken boş elle sağ tık = otur/kalk. Seni takip eder.
- **Eşyalar (25):** kılıçlar, baltalar, çekiçler, mızraklar, yaylar, oklar, 3 kazma (gerçek kazma), Kayı Bayrağı, Lahmacun (8 açlık + 7 can).
- **Tarifler:** Bedrock'taki tariflerin hepsi (kitapsız, malzeme olunca üretilir).
- Ganimet tabloları, yaratık spawn'ları, yaratıcı mod sekmesi (Osman Gazi), TR/EN dil.

## v2.0.0 ile gelenler
- **Süvariler:** Alp, Moğol ve Barbar Süvarisi. Atın üstünde doğarlar, mızrakla savaşırlar, evcilleştirilebilirler.
- **Atlar:** Alp, Moğol ve Barbar Atı. Evcilleştirdikten sonra boş elle sağ tıkla ve bin. Eyer gerekmez.
- **Topçular:** Alp, Moğol ve Barbar Topçusu. **El Topçusu** ve **Gülle** eşyaları (gülle patlar, bloğa ve dostlara zarar vermez).
- **Osman Gazi Rehberi:** oyun içi kitap, tüm evcilleştirme bilgilerini gösterir. Tarif: kitap + demir külçe.
- Mod tamamen Türkçedir (oyun dili ne olursa olsun).

## Sonraki aşama (henüz yok)
Özel üretim masası (tüm silahlar ve aletler orada üretilecek), kaleler ve ferman eşyaları, toplar, kazmacının cevher kazma görevi, `/osmangazi` komutu.

## Derleme (jar üretme)
Yöntem A - GitHub Actions (en kolay): bu klasörü yeni bir GitHub deposuna yükle. "Actions" sekmesinde `build` çalışır, bitince
`OsmanGazi-forge-1.20.1` çıktısının içinden jar'ı indir.

Yöntem B - Resmi MDK ile: Forge 1.20.1-47.3.0 MDK'sını indir, aç. İçindeki `src` klasörünü sil, bu projenin `src` klasörünü koy.
`gradle.properties` içinde `mod_id=osmangazi` yap. Sonra `gradlew build` yaz. Jar `build/libs` içinde çıkar.

Gereken: JDK 17.

## Kurulum
1. Minecraft Java 1.20.1 + Forge 47.3.0 kur.
2. Jar'ı `mods` klasörüne at.
3. `OsmanGazi_Forge_ResourcePack.zip` dosyasını `resourcepacks` klasörüne at ve oyunda etkinleştir (dokular mod içinde de var; paket aynı dokuları verir).
